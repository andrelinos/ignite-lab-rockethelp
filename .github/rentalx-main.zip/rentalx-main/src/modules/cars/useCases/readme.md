## USE CASES

### UTILIZANDO O CONCEITO DO SOLID

* Todas as vezes que pensarmos em use case, são as funcionalidades que nossa aplicação vai ter.
* Todas as vezes que tivermos uma nova funcionalida, teremos uma nova pasta para esse use case.

* Dentro de cada pasta do use case, teremos:
  - Controller
  - useCase
